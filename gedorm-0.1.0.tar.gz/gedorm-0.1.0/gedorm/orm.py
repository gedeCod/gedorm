import sqlite3
import json
from datetime import datetime

class ValidationError(Exception):
    pass

class BaseModel:
    table_name = ''
    _connection = None

    @classmethod
    def connect(cls):
        if cls._connection is None:
            cls._connection = sqlite3.connect('database.db')

    @classmethod
    def create_table(cls):
        cls.connect()
        cursor = cls._connection.cursor()
        cursor.execute(f'''
            CREATE TABLE IF NOT EXISTS {cls.table_name} (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                {', '.join([f"{field} TEXT" for field in cls.__annotations__.keys()])}
            )
        ''')
        cls._connection.commit()

    @classmethod
    def all(cls):
        cls.connect()
        cursor = cls._connection.cursor()
        cursor.execute(f'SELECT * FROM {cls.table_name}')
        return cls._convert_data(cursor.fetchall())

    @classmethod
    def find(cls, id):
        cls.connect()
        cursor = cls._connection.cursor()
        cursor.execute(f'SELECT * FROM {cls.table_name} WHERE id = ?', (id,))
        return cls._convert_data(cursor.fetchone())

    @classmethod
    def update(cls, id, **kwargs):
        cls.connect()
        cls.validate(kwargs)  # Validation avant mise à jour
        cursor = cls._connection.cursor()
        fields = ', '.join([f"{key} = ?" for key in kwargs.keys()])
        values = list(cls._prepare_data(kwargs))
        values.append(id)
        cursor.execute(f'UPDATE {cls.table_name} SET {fields} WHERE id = ?', values)
        cls._connection.commit()

    @classmethod
    def delete(cls, id):
        cls.connect()
        cursor = cls._connection.cursor()
        cursor.execute(f'DELETE FROM {cls.table_name} WHERE id = ?', (id,))
        cls._connection.commit()

    @classmethod
    def begin_transaction(cls):
        cls.connect()
        cls._connection.execute('BEGIN TRANSACTION')

    @classmethod
    def commit_transaction(cls):
        cls.connect()
        cls._connection.commit()

    @classmethod
    def rollback_transaction(cls):
        cls.connect()
        cls._connection.rollback()

    @classmethod
    def migrate(cls, migration):
        cls.connect()
        cursor = cls._connection.cursor()
        migration.apply(cursor)
        cls._connection.commit()

    @classmethod
    def validate(cls, data):
        for field, value in data.items():
            if not value:
                raise ValidationError(f"{field} ne peut pas être vide.")

    @classmethod
    def _prepare_data(cls, data):
        """Convertit les types de données en chaînes pour la base de données."""
        for key, value in data.items():
            if isinstance(value, dict) or isinstance(value, list):
                data[key] = json.dumps(value)  # Convertir en JSON
            elif isinstance(value, datetime):
                data[key] = value.isoformat()  # Convertir en chaîne de date
        return data.values()

    @classmethod
    def _convert_data(cls, rows):
        """Convertit les chaînes de la base de données en types de données appropriés."""
        converted_rows = []
        for row in rows:
            converted_row = {}
            for idx, value in enumerate(row):
                if isinstance(value, str) and (value.startswith('{') or value.startswith('[')):
                    # Tentative de convertir JSON
                    try:
                        converted_row[cls.__annotations__.keys()[idx]] = json.loads(value)
                    except json.JSONDecodeError:
                        converted_row[cls.__annotations__.keys()[idx]] = value
                elif isinstance(value, str) and len(value) == 10 and '-' in value:
                    # Tentative de convertir une date
                    try:
                        converted_row[cls.__annotations__.keys()[idx]] = datetime.fromisoformat(value)
                    except ValueError:
                        converted_row[cls.__annotations__.keys()[idx]] = value
                else:
                    converted_row[cls.__annotations__.keys()[idx]] = value
            converted_rows.append(converted_row)
        return converted_rows

class User(BaseModel):
    table_name = 'users'
    name: str
    email: str

    @classmethod
    def validate(cls, data):
        super().validate(data)
        if 'email' in data and '@' not in data['email']:
            raise ValidationError("L'email doit être valide.")

class Profile(BaseModel):
    table_name = 'profiles'
    user_id: int  # Relation one-to-one
    bio: str
    preferences: dict  # Support des types de données

class Post(BaseModel):
    table_name = 'posts'
    user_id: int  # Relation one-to-many
    content: str
    created_at: datetime  # Support des types de données
    media: bytes = None  # Support des données multimédia

    @classmethod
    def validate(cls, data):
        super().validate(data)
        if 'content' in data and len(data['content']) < 5:
            raise ValidationError("Le contenu doit contenir au moins 5 caractères.")

class Tag(BaseModel):
    table_name = 'tags'
    name: str

class PostTag(BaseModel):
    table_name = 'post_tags'  # Relation many-to-many
    post_id: int
    tag_id: int

# Classes de migration pour créer les tables
class Migration:
    def apply(self, cursor):
        raise NotImplementedError("La méthode 'apply' doit être implémentée.")

class CreateUserTable(Migration):
    def apply(self, cursor):
        cursor.execute('''
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                email TEXT,
                UNIQUE(email)  -- Index unique sur l'email
            )
        ''')

class CreateProfileTable(Migration):
    def apply(self, cursor):
        cursor.execute('''
            CREATE TABLE profiles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                bio TEXT,
                preferences TEXT,  -- Support des données JSON
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE  -- Clé étrangère
            )
        ''')
        cursor.execute('CREATE INDEX idx_user_id ON profiles(user_id)')  # Index sur user_id

class CreatePostTable(Migration):
    def apply(self, cursor):
        cursor.execute('''
            CREATE TABLE posts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                content TEXT,
                created_at TEXT,
                media BLOB,  -- Support des données multimédia
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE  -- Clé étrangère
            )
        ''')
        cursor.execute('CREATE INDEX idx_user_id ON posts(user_id)')  # Index sur user_id

class CreateTagTable(Migration):
    def apply(self, cursor):
        cursor.execute('''
            CREATE TABLE tags (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT
            )
        ''')

class CreatePostTagTable(Migration):
    def apply(self, cursor):
        cursor.execute('''
            CREATE TABLE post_tags (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                post_id INTEGER,
                tag_id INTEGER,
                FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,  -- Clé étrangère
                FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE   -- Clé étrangère
            )
        ''')
        cursor.execute('CREATE INDEX idx_post_id ON post_tags(post_id)')  # Index sur post_id
        cursor.execute('CREATE INDEX idx_tag_id ON post_tags(tag_id)')    # Index sur tag_id

# Utilisation de l'ORM
if __name__ == '__main__':
    # Appliquer les migrations
    BaseModel.migrate(CreateUserTable())
    BaseModel.migrate(CreateProfileTable())
    BaseModel.migrate(CreatePostTable())
    BaseModel.migrate(CreateTagTable())
    BaseModel.migrate(CreatePostTagTable())

    # Gestion des transactions
    try:
        BaseModel.begin_transaction()  # Commencer la transaction

        # Créer un nouvel utilisateur
        user = User()
        user.name = 'John Doe'
        user.email = 'john@example.com'
        user.validate({'name': user.name, 'email': user.email})  # Validation
        user.save()

        # Créer un profil pour l'utilisateur
        profile = Profile()
        profile.user_id = 1  # Associer au premier utilisateur
        profile.bio = 'Développeur Python'
        profile.preferences = {'theme': 'dark', 'notifications': True}  # Support JSON
        profile.save()

        # Créer un post pour l'utilisateur avec des données multimédia
        post = Post()
        post.user_id = 1  # Associer au premier utilisateur
        post.content = 'Hello World!'
        post.created_at = datetime.now()  # Support des dates

        # Charger des données multimédia (exemple avec des données fictives)
        with open('example_image.png', 'rb') as file:
            post.media = file.read()  # Charger le fichier image en tant que BLOB
        post.validate({'content': post.content})  # Validation
        post.save()

        # Ajouter des tags
        tag1 = Tag()
        tag1.name = 'Python'
        tag1.save()

        tag2 = Tag()
        tag2.name = 'Développement'
        tag2.save()

        # Associer les tags au post
        post_tag1 = PostTag()
        post_tag1.post_id = 1
        post_tag1.tag_id = 1
        post_tag1.save()

        post_tag2 = PostTag()
        post_tag2.post_id = 1
        post_tag2.tag_id = 2
        post_tag2.save()

        BaseModel.commit_transaction()  # Valider la transaction

    except ValidationError as ve:
        print(f"Erreur de validation : {ve}")
        BaseModel.rollback_transaction()  # Annuler la transaction en cas d'erreur
    except Exception as e:
        print(f"Erreur : {e}")
        BaseModel.rollback_transaction()  # Annuler la transaction en cas d'erreur

    # Récupérer et afficher les données
    print("Utilisateurs:")
    for user in User.all():
        print(user)

    print("\nProfils:")
    for profile in Profile.all():
        print(profile)

    print("\nPosts:")
    for post in Post.all():
        print(post)

    print("\nTags:")
    for tag in Tag.all():
        print(tag)

    print("\nPost Tags:")
    for post_tag in PostTag.all():
        print(post_tag)