Documentaire : Utilisation de GedeORM
Bienvenue dans ce documentaire sur GedeORM, un ORM simple et efficace pour gérer des bases de données SQLite en Python. Ce guide vous montrera comment installer, configurer et utiliser GedeORM pour vos projets, en mettant en avant ses principales fonctionnalités.

Qu'est-ce que GedeORM ?
GedeORM est un Object-Relational Mapping (ORM) qui facilite l'interaction avec les bases de données SQLite. Il vous permet de manipuler des données de manière intuitive en utilisant des objets Python, tout en prenant en charge des fonctionnalités comme la validation des données, le stockage de données multimédia, et la gestion des relations entre les tables.

Installation
Prérequis
Avant de commencer, assurez-vous d'avoir Python 3.6 ou une version ultérieure installé sur votre machine.

Installation de GedeORM
Pour installer GedeORM, ouvrez votre terminal ou votre invite de commandes et exécutez la commande suivante :

bash

Copier
pip install gedeorm
Configuration de GedeORM
Création d'une Base de Données
GedeORM utilise SQLite par défaut. Vous n'avez pas besoin de créer une base de données manuellement, car GedeORM s'en charge pour vous lors de la première utilisation.

Exemple de Structure de Projet
Créez un nouveau dossier pour votre projet et un fichier Python, par exemple app.py, où vous allez utiliser GedeORM.


Copier
mon_projet/
    app.py
Utilisation de GedeORM
Étape 1 : Importer GedeORM
Dans votre fichier app.py, commencez par importer les classes nécessaires de GedeORM :

python

Exécuter

Copier
from gedeorm import User, Profile, Post, Tag, PostTag
Étape 2 : Créer les Tables
Avant de pouvoir utiliser GedeORM, vous devez créer les tables nécessaires dans votre base de données. Voici comment le faire :

python

Exécuter

Copier
if __name__ == '__main__':
    # Appliquer les migrations pour créer les tables
    User.create_table()
    Profile.create_table()
    Post.create_table()
    Tag.create_table()
    PostTag.create_table()
Étape 3 : Ajouter des Données
Vous pouvez maintenant ajouter des utilisateurs, des profils, des posts et des tags. Voici un exemple :

python

Exécuter

Copier
# Ajouter un utilisateur
user = User()
user.name = 'Alice'
user.email = 'alice@example.com'
user.save()  # Enregistre l'utilisateur dans la base de données

# Ajouter un profil
profile = Profile()
profile.user_id = 1  # Associer au premier utilisateur
profile.bio = 'Développeuse Python'
profile.preferences = {'theme': 'light', 'notifications': True}
profile.save()  # Enregistre le profil

# Ajouter un post
post = Post()
post.user_id = 1  # Associer au premier utilisateur
post.content = 'Bonjour tout le monde !'
post.created_at = datetime.now()  # Date actuelle
post.save()  # Enregistre le post

# Ajouter un tag
tag = Tag()
tag.name = 'Bonjour'
tag.save()  # Enregistre le tag
Étape 4 : Récupérer des Données
Pour récupérer les données, vous pouvez utiliser les méthodes all() et find() :

python

Exécuter

Copier
# Récupérer tous les utilisateurs
for user in User.all():
    print(user)

# Trouver un utilisateur par ID
user = User.find(1)
print(user)
Étape 5 : Mettre à jour et Supprimer des Données
Vous pouvez facilement mettre à jour ou supprimer des enregistrements :

python

Exécuter

Copier
# Mettre à jour un utilisateur
user = User.find(1)
user.email = 'alice_new@example.com'
user.save()  # Enregistre les modifications

# Supprimer un utilisateur
User.delete(1)  # Supprime l'utilisateur avec ID 1
Étape 6 : Gestion des Transactions
GedeORM facilite également la gestion des transactions. Voici comment l'utiliser :

python

Exécuter

Copier
try:
    BaseModel.begin_transaction()  # Commencer la transaction

    # Effectuer plusieurs opérations
    user = User()
    user.name = 'Bob'
    user.email = 'bob@example.com'
    user.save()

    profile = Profile()
    profile.user_id = 2  # Associer au nouvel utilisateur
    profile.bio = 'Développeur Web'
    profile.save()

    BaseModel.commit_transaction()  # Valider la transaction
except Exception as e:
    print(f"Erreur : {e}")
    BaseModel.rollback_transaction()  # Annuler en cas d'erreur
Conclusion
GedeORM est un outil puissant et facile à utiliser pour gérer des bases de données SQLite en Python. Avec ses fonctionnalités de validation, de gestion des relations et de prise en charge des données multimédia, il vous permet de développer rapidement des applications robustes.

N'hésitez pas à consulter la documentation de GedeORM pour explorer toutes ses capacités et à l'utiliser dans vos projets. Merci d'avoir suivi ce documentaire !